<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style.css" rel="stylesheet" type="text/css" />
    <script src="javascript.js" type="module" defer></script>
    <?php
    session_start();
    if(isset($_SESSION['role'])) {
        if($_SESSION['role']=="admin"){
            echo '<link href="styleAdmin.css" rel="stylesheet" type="text/css" />';
        } else {
            echo '<link href="styleUser.css" rel="stylesheet" type="text/css" />';
        }
    }
    ?>
    <title>ECF MEESE Romain</title>
</head>

<body>
    <header>
        <?php
        include "header.php";
        ?>
    </header>
    <main>
        <?php
        //SQL X premiers posts
        //$result = include "getPosts.php";
        //Affichage sous form <div><h1/><h2/><p/><footer/></div> de chaque post:

        ?>
    </main>
    <footer>
        <!--Pagination-->
        <button><== Précédent</button>
        <button>Suivant ==></button>
    </footer>
</body>

</html>