<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style.css" rel="stylesheet" type="text/css" />
    <?php
    session_start();
    if(isset($_SESSION['role'])) {
        if($_SESSION['role']=="admin"){
            echo '<link href="styleAdmin.css" rel="stylesheet" type="text/css" />';
        } else {
            echo '<link href="styleUser.css" rel="stylesheet" type="text/css" />';
        }
    }
    ?>
    <title>Login</title>
</head>

<body>
    <header>
        <?php
        include "header.php";
        ?>
    </header>
    <aside>
        <span id="message"></span>
    </aside>
    <main>
        <form action="#" method="post">
            <div>
                <label for="login">Login:</label>
                <input type="text" name="login">
            </div>
            <div>
                <label for="password">Mot de passe:</label>
                <input type="password" name="password">
            </div>
            <button type="submit" id="submit" name="submit" value="Valider">Valider</button>
        </form>
        <?php
        include "seConnecter.php";
        ?>
    </main>
</body>

</html>