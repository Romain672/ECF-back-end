<a href="accueil.php">Accueil</a>
<?php
if (isset($_SESSION['role'])) {
?>
    <a href="deconnexion.php">Se déconnecter</a>
<?php
    if ($_SESSION['role'] =="admin") {
        ?>
        <a href="administration.php">Administration</a>
        <?php
    }
} else {
?>
    <a href="connexion.php">Se connecter</a>
<?php
}
?>