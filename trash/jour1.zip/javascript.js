let postsPerPage = 12;
let pageActuelle = 0;
let charactersMaximumDisplayedOnBody = 50;

document
  .querySelectorAll("footer button")[0]
  .addEventListener("click", clickPrecedent);
document
  .querySelectorAll("footer button")[1]
  .addEventListener("click", clickSuivant);

async function clickPrecedent(event) {
  pageActuelle--;
  displayPosts();
  if (pageActuelle == 0) {
    event.target.style.visibility = "hidden";
  }
  document.querySelectorAll("footer button")[1].style.visibility = "visible";
}
async function clickSuivant(event) {
  pageActuelle++;
  let message = await displayPosts();
  if (pageActuelle == 1) {
    document.querySelectorAll("footer button")[0].style.visibility = "visible";
  }

  //Cas particuliers
  if (message == "fin atteinte auparavant") { //Aucun résultat sur la page suivante => dernière page atteinte auparavant
    pageActuelle--;
    event.target.style.visibility = "hidden";
  }
  if (message == "fin atteinte") { //Résultats inférieur à ce qui a été demandé => dernière page
    event.target.style.visibility = "hidden";
  }
  //
}

displayPosts();

//Affichage
async function callApi(url) {
  const response = await fetch(url);
  const data = await response.json();
  return data;
}
async function displayPosts() {
  let result = await callApi(
    "getPosts.php?postsPerPage=" +
      postsPerPage +
      "&pageActuelle=" +
      pageActuelle
  );

  if (result.length > 0) {
    let main = document.querySelector("main");
    main.innerHTML = "";
    for (var line of result) {
      const newDiv = document.createElement("div");
      const newH1 = document.createElement("h1");
      newH1.innerHTML = majusculeMinuscules(line.title) + ":";
      newDiv.appendChild(newH1);
      const newH2 = document.createElement("h2");
      newH2.innerHTML = "#" + line.id;
      newDiv.appendChild(newH2);
      const newP = document.createElement("p");
    
      let string = line.body;
        for (let i=charactersMaximumDisplayedOnBody;i>0;i--){
            if(string[i]==" "){
                newP.innerHTML = line.body.substring(0, i) + "...";
                break;
            }
        }
        if (newP.innerHTML == string){ //aucun espace dans le début du body
            newP.innerHTML = line.body.substring(0, charactersMaximumDisplayedOnBody) + "...";
        }
     
      newDiv.appendChild(newP);
      const newFooter = document.createElement("footer");
      newFooter.innerHTML =
        "Posted by " + majusculeMinuscules(line.username) + " the " + line.createdAt;
      newDiv.appendChild(newFooter);
      main.append(newDiv);

      const divBouton = document.createElement("div");
      newDiv.appendChild(divBouton);
      const newBouton = document.createElement("bouton");
      newBouton.src = line.id;
      newBouton.innerHTML = "Voir plus";
      newBouton.addEventListener("click", function (event) {newP.innerHTML = result.find((element) => element.id==event.target.src).body});
      divBouton.appendChild(newBouton);

      main.append(newDiv);
    }
  }

  if (result.length == 0){
    return "fin atteinte auparavant";
  }
  if (result.length == postsPerPage) {
    return "nombre de résultats normaux";
  } else {
    return "fin atteinte";
  }
}

function majusculeMinuscules (string) {
    return string[0].toUpperCase() + string.substring(1).toLowerCase();
}