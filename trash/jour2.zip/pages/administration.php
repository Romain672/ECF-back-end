<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>
        let postsPerPage = 200;
        let charactersMaximumDisplayedOnBody = 50;
    </script>
    <style>
        <?php
        include "../assets/style/style.css";
        include "../assets/style/stylePageAdmin.css";
        ?>
    </style>
    <?php
    if(isset($_SESSION['role'])) {
        if($_SESSION['role']=="admin"){
            ?><style><?php
            include "../assets/style/styleAdmin.css";
            ?></style><?php
        } else {
            ?><style><?php
            include "../assets/style/styleUser.css";
            ?></style><?php
        }
    }
    ?>
    <title>Administration</title>
</head>

<body>
    <header>
        <?php
        include "../assets/php/header.php";
        ?>
    </header>
    <main></main>
    <footer>
        <!--Pagination-->
        <button><== Précédent</button>
        <button>Suivant ==></button>
    </footer>


    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script>
        <?php
        include "../assets/javascript/displayPosts.js";
        include "../assets/javascript/administration.js";
        ?>
    </script>
</body>

</html>