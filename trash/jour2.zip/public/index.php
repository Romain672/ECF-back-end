<?php
//$postsPerPage = 12;
//$pageActuelle = 0;

//header('Location: ../pages/accueil.php');
//include "../pages/accueil.php";

$uri = $_SERVER['REQUEST_URI'];

/*
include "../../vendor/autoload.php";
$router = new AltoRouter();
$router->map('GET', '/', function () {
    echo "Bienvenue";
});
var_dump($router);
*/

if (!isset($_SESSION)){
    session_start();
}

if ($uri == "/administration") {
    if (isset($_SESSION['role'])) {
        if ($_SESSION['role'] == "admin") {
            include "../pages/administration.php";
        } else {
            include "../pages/connexion.php";
        }
    } else {
        include "../pages/connexion.php";
    }
}
if ($uri == "/accueil") {
    include "../pages/accueil.php";
}
if ($uri == "/connexion") {
    include "../pages/connexion.php";
}

if ($uri == "/deconnexion") {
    include "../assets/php/deconnexion.php";
}

if (preg_match("/\/index\.php\/callApi\?postsPerPage=([0-9]+)\&pageActuelle=([0-9]+)/", $uri)) {
    include "../assets/php/getPosts.php";
}
if($uri == "/index.php/deletePost"){
    include "../assets/php/deletePost.php";
}